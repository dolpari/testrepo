<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style>
th { background-color: #ddd; border-bottom: 3px double #000; }
th, td { padding: 5px; }
</style>
</head>

<body>

<!-- <img src="./img/prized.PNG" /><br /><br /> -->
<table border=1 style="border-collapse: collapse;font-size:15px">
<thead>
<tr>
	<th>년차</th>
	<th>일정</th>
	<th>수상자</th>
</tr>
</thead>
<tbody>
<tr>
	<td>제 1회</td>
	<td>2003년 10월 30일(목)</td>
	<td>최우수상 : 하동주(정보보호)<br>
우 수 상 : 이광우(정보보호), 유용우(전자공)<br>
장 려 상 : 구자연(정보기술), 문영조(정보보호), 최현우(정보보호)</td>
</tr>
<tr>
        <td>제 2회</td>
        <td>2004년 12월 02일(목)</td>
        <td>최우수상 : 김우현(문성고등학교), 이광우(정보보호)<br>
우 수 상 : 신정훈(청담정보고등학교), 하동주(정보보호)<br>
장 려 상 : 김진우(서라벌고등학교), 김형준(화수고등학교), <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;류용우(정보기술), 전지원(정보보호)</td>
</tr>
<tr>
        <td>제 3회</td>
        <td>2005년 12월 08일(목)</td>
        <td>최우수상 : 박찬암(부산남산고등학교), 이광형(정보보호)<br>
우 수 상 : 김진우(서라벌고등학교), 김영곤(정보기술)<br>
장 려 상 : 신정훈(청담정보고등학교), 정태영(정보보호)</td>
</tr>
<tr>
        <td>제 4회</td>
        <td>2006년 07월 18일(화)</td>
        <td>최우수상 : 이병윤(선린인터넷고등학교)<br>
우 수 상 : 박찬암(부산남산고등학교)<br>
장 려 상 : 방승원(인천정보산업고등학교)</td>
</tr>
<tr>
        <td>제 5회</td>
        <td>2007년 09월 13일(목)</td>
        <td>최우수상 : 박찬암(부산남산고등학교)<br>
우 수 상 : 구사무엘(선린인터넷고등학교)<br>
장 려 상 : 임동욱(선린인터넷고등학교)</td>
</tr>
<tr>
        <td>제 6회</td>
        <td>2008년 09월 11일(목)</td>
        <td>최우수상 : 임동욱(도봉정보산업고등학교)<br>
우 수 상 : 김동억(선린인터넷고등학교)<br>
장 려 상 : 이지용(한국과학영재학교)</td>
</tr>
<tr>
        <td>제 7회</td>
        <td>2009년 09월 15일(화)</td>
        <td>최우수상 : 이대근(한국과학영재학교)<br>
우 수 상 : 이종호(한솔고등학교)<br>
장 려 상 : 김승연(상봉중학교)</td>
</tr>
<tr>
        <td>제 8회</td>
        <td>2010년 11월 19일(금)</td>
        <td>최우수상 : 이정훈(한국게임과학고등학교)<br>
우 수 상 : 박성환(성도고등학교)<br>
장 려 상 : 김동주(부산동천고등학교)</td>
</tr>
<tr>
        <td>제 9회</td>
        <td>2011년 11월 01일(금)</td>
        <td>최우수상 : 이정훈(한국게임과학고등학교)<br>
우 수 상 : 권혁(과천고등학교)<br>
장 려 상 : 김동선(한국디지털미디어고등학교)</td>
</tr>
<tr>
        <td>제 10회</td>
        <td>2012년 09월 12일(목)</td>
        <td>최우수상 : 이호준(미재학)<br>
우 수 상 : 금승현(강북고등학교), 강인욱(선린인터넷고등학교)<br>
장 려 상 : 김희중(선린인터넷고등학교), 권혁주(대성고등학교), <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;임정원(선린인터넷고등학교), 이선엽(부평고등학교),<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;권혁(과천고등학교)</td>
</tr>
<tr>
        <td>제 11회</td>
        <td>2013년 09월 13일(금)</td>
        <td>최우수상 : 임정원(선린인터넷고등학교)<br>
우 수 상 : 진용휘(일산동고등학교), 이선엽(부평고등학교)<br>
장 려 상 : 권혁주(대성고등학교), 차성호(선린인터넷고등학교),<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;강인욱(선린인터넷고등학교), 이상섭(부천상동고등학교),<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;현성원(대원고등학교)</td>
</tr>
<tr>
        <td>제 12회</td>
        <td>2014년 09월 04일(목)</td>
        <td>최우수상 : 이선엽(부평고등학교)<br>
우 수 상 : 박선주(선린인터넷고등학교), 배경준(한세사이버보안고등학교)<br>
장 려 상 : 양해찬(한국디지털미디어고등학교), 서승완(한국디지털미디어고등학교), <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;김승현(세일고등학교), 이시훈(선린인터넷고등학교),<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;손호성(한국디지털미디어고등학교), 이동관(과천외국어고등학교)</td>
</tr>
<tr>
	<td>제 13회</td>
	<td>2015년 09월 03일(목)</td>
	<td>최우수상 : 박선주(선린인터넷고등학교)<br>
우 수 상 : 박서빈(국립부산기계공업고등학교), 이시훈(선린인터넷고등학교)<br>
장 려 상 : 김승환(한국디지털미디어고등학교), 변준우(선린인터넷고등학교), <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;김도현(선린인터넷고등학교), 김승현(세일고등학교), <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;김영호(선린인터넷고등학교), 김준기(선린인터넷고등학교)</td>
</tr>
<tr>
        <td>제 14회</td>
        <td>2016년 09월 22일(목)</td>
        <td>최우수상 : 변준우(선린인터넷고등학교)<br>
우 수 상 : 김승환(한국디지털미디어고등학교), 오우진(운호고등학교)<br>
장 려 상 : 김낙현(선린인터넷고등학교), 장혁(대전관저중학교), <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;이태양(한국디지털미디어고등학교), 손진혁(동인고등학교), <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;이시훈(선린인터넷고등학교), 서민교(능동고등학교)</td>
</tr>
<tr>
	<td>제 15회</td>
	<td>2017년 09월 14일(목)</td>
	<td>최우수상 : 임준오(선린인터넷고등학교)<br>
우 수 상 : 이태양(한국디지털미디어고등학교), 장혁(서일고등학교)<br>
장 려 상 : 김승환(한국디지털미디어고등학교), 강연호(거제제일고등학교), <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;차현수(부산용인고등학교), 이든솔(상계중학교), <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;이영주(선린인터넷고등학교), 장세한(선린인터넷고등학교)</td>
</tr>
<tr>
   <td>제 16회</td>
   <td>2018년 09월 20일(목)</td>
   <td>최우수상 : 차현수(부산용인고등학교)<br>
우 수 상 : 이든솔(선린인터넷고등학교), 안건희(선린인터넷고등학교)<br>
장 려 상 : 김민석(서울디지텍고등학교), 장경호(한세사이버고등학교), <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;이효민(선린인터넷고등학교), 이 &nbsp; 현(선린인터넷고등학교), <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;장 &nbsp; 혁(대전서일고등학교), 권예준(선린인터넷고등학교)</td>
</tr>
</tbody>
</table>
</body>
</html>
