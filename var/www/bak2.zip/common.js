﻿$(function(){
	$('#poster').dialog({
		modal : true,
		title : "포스터",
		height : 850,
		width : 590
	});

	$('#register').dialog({
		modal : true,
		title : "가입신청",
		width : 850
	});

	$('#prize').dialog({
		modal : true,
		title : "수상자",
		width : 600,
		height : 670
	});

	$('#notice').dialog({
		modal : true,
		title : "공지",
		width : 580,
		height : 640
	});

	$('#qnwjd').dialog({
		modal : true,
		title : "부정행위 관련 공지",
		width : 590,
		height: 800
	});
});
